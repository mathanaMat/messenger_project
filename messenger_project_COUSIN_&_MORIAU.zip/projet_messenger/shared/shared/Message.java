package shared;

import java.io.Serializable;
import java.util.Date;

public class Message implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7233126847452047408L;
	
	//we don't want accessor for this class.
	private String messageContent;
	private User author;
	
	@SuppressWarnings("unused")
	private Date dateCreation;
	
	private int topic_id;
	
	public Message(String messageContent, User author, int topic_id){
		
		this.messageContent = messageContent;
		this.author = author;
		this.dateCreation = new Date();
		this.topic_id = topic_id;
	}
	
	public String get_messageContent() {return this.messageContent;}
	
	public String get_author() {
		
		return this.author.get_userName();
	}
	
}
