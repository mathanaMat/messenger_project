package shared;

import java.io.Serializable;

public class Request_Register implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7779311307897982449L;
	
	private String userName;
	private String clearPassword;
	
	public Request_Register(String userName, String clearPassword){
		
		this.userName = userName;
		this.clearPassword = clearPassword;
	}
	
	public String read_userName() {return this.userName;}
	
	public String read_clearPassword() {return this.clearPassword;}
	
}
