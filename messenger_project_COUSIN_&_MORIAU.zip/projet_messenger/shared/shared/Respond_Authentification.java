package shared;

import java.io.Serializable;

public class Respond_Authentification implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -47525471471954350L;
	
	private boolean authOK;
	private User userConnected;
	
	public Respond_Authentification(boolean authOK) {
		
		this.authOK = authOK;
	}
	
	public Respond_Authentification(boolean authOK, User userConnected) {
		
		this.authOK = authOK;
		this.userConnected = userConnected;
	}
	
	public boolean is_auth_OK() {return this.authOK;}
	
	public User get_userConnected() {return this.userConnected;}
	
}
