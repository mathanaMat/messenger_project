/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shared;

import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Date;

/**
 *
 * @author Mathana
 */
public class User implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -1051499830533802805L;
	
	//we don't want accesors for this class
    private String userName;
    //IMPORTANT NOTICE: password should be hash.
    @SuppressWarnings("unused")
	private byte[] hashPassword;
    
    private String clearPassword;
    private int user_id;
    
    @SuppressWarnings("unused")
	private Date dateCreation;
    
    //IMPORTANT ! Each user should have a UNIQUE user_id linked to each user name.
    //IMPORTANT ! user_id must be generated at a higher level.
    public User(String userName, String clearPassword, int user_id) throws NoSuchAlgorithmException{
    	
        this.userName = userName;
        this.dateCreation = new Date();
        //save hash from clear password:
        this.hashPassword = MessageDigest.getInstance("SHA-256").digest(clearPassword.getBytes(StandardCharsets.UTF_8));
        this.clearPassword = clearPassword;
        this.user_id = user_id;
        
    }
    
    //IMPORANT NOTICE: Constructor to use with high level password hash only !
    public User(String userName, byte[] hashPassword, int user_id){
    	
        this.userName = userName;
        //save hash generated at higher level.
        this.hashPassword = hashPassword;
        this.user_id = user_id;
        
    }
    
    public void changePass(String newPass) throws NoSuchAlgorithmException{
        this.hashPassword = MessageDigest.getInstance("SHA-256").digest(newPass.getBytes(StandardCharsets.UTF_8));
    }
    
    public String get_userName(){
        return this.userName;
    }
    
    public boolean verif_password(String clearPassword) {
    	
    	boolean match = false;
    	
    	if(this.clearPassword.equalsIgnoreCase(clearPassword))
    		match = true;
    	
    	return match;
    }
    
    public int get_user_id(){
        return this.user_id;
    }
    
    private void HashThePass(){
        
    }
}
