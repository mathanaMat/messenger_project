/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shared;

import java.io.Serializable;
import java.util.ArrayList;
//import java.util.Date;


/**
 *
 * @author Mathana
 */
public class Topic implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -352966050616204179L;
	
	//we don't want accessor for this class.
    private String topicName;
    private int topic_id;
    private ArrayList<Message> messages;
    
    //Each topic must have a UNIQUE topic_id.
    public Topic(String topicName, int topic_id){
    	
        //set this topic name:
        this.topicName = topicName;
        //set the topic_id:
        this.topic_id = topic_id;
        messages = new ArrayList<Message>();
    }
    
    public Topic(String topicName){
    	
    	this.topicName = topicName;
    }
    
    public void addMessage(Message newMessage){
    	
    	this.messages.add(newMessage);
    }
    
    public int get_topic_id() {return this.topic_id;}
    
    public String get_topicName() {return this.topicName;}
    
    public ArrayList<Message> get_messages(){return this.messages;}
    
    public int getNumberOfMsg()	{return messages.size();}
}