package shared;

import java.io.Serializable;
import java.util.ArrayList;

public class Respond_ListTopics implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -224168265335959334L;
	
	private ArrayList<String> List_topicName;
	private ArrayList<Integer> List_topic_id;
	
	public Respond_ListTopics(ArrayList<Topic> TopicList){
		
		List_topicName = new ArrayList<String>();
		List_topic_id = new ArrayList<Integer>();
		
		for(int i = 0; i < TopicList.size(); i++)
		{
			List_topicName.add(TopicList.get(i).get_topicName());
			List_topic_id.add(TopicList.get(i).get_topic_id());
		}
	}
	
	public ArrayList<String> read_List_topicName(){return this.List_topicName;}
	
	public ArrayList<Integer> read_List_topic_id(){return this.List_topic_id;}	
}
