package shared;

import java.io.Serializable;

public class Request_Disconnect implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 9210199219402060552L;

}
