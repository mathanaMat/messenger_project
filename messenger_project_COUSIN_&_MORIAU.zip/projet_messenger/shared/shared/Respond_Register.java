package shared;

import java.io.Serializable;

public class Respond_Register implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8686041290864002305L;
	
	private boolean usernameUnique;
	
	public Respond_Register(boolean usernameUnique){
		
		this.usernameUnique = usernameUnique;
	}
	
	public boolean username_unique() {return this.usernameUnique;}
	
}
