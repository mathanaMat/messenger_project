package shared;

import java.io.Serializable;

public class Request_ListTopics implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8285751532303779165L;

	
}
