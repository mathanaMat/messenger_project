package shared;

import java.io.Serializable;
//import java.util.ArrayList;

public class Request_NewTopic implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5173809498817447366L;
	
	private String topicName;
	
	public Request_NewTopic(String topicName){
		
		this.topicName = topicName;
	}

	public String read_topicName() {return this.topicName;}
}
