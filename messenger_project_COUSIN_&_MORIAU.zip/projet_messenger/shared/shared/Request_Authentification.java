package shared;

import java.io.Serializable;

public class Request_Authentification implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4719763361442474935L;
	
	private String userName;
	private String clearPassword;
	
	public Request_Authentification(String userName, String clearPassword){
		
		this.userName = userName;
		this.clearPassword = clearPassword;
	}
	
	public String read_userName() {return this.userName;}
	
	public String read_clearPassword() {return this.clearPassword;}

}
