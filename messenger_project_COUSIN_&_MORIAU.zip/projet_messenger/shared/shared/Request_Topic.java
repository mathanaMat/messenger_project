package shared;

import java.io.Serializable;

public class Request_Topic implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2960320063930925113L;
	
	private int topic_id;
	
	public Request_Topic(int topic_id){
		
		this.topic_id = topic_id;
	}
	
	public int read_topic_id() {return this.topic_id;}
}
