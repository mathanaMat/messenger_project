package server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

import shared.*;

public class ClientHandler implements Runnable {
	Socket client;
	ObjectInputStream ois;
	ObjectOutputStream oos;
	ReadRequest myRequest;
	int currentTopicId = -1;
	int nbTopicMsg = -1;
	
	private ArrayList<Topic> TopicList = new ArrayList<Topic>();
	private ArrayList<User> UserList = new ArrayList<User>();
	
	public ClientHandler(Socket client, ArrayList<Topic> TopicList, ArrayList<User> UserList) throws IOException	{
		System.out.println("Init ClientHandler");
		this.client = client;
		oos = new ObjectOutputStream(client.getOutputStream());
		oos.flush();
		this.TopicList = TopicList;
		this.UserList = UserList;
		myRequest = new ReadRequest(client);
		(new Thread(myRequest)).start();
		//myRequest.run();
		//this.run();
	}
	
	public void getRequest() throws ClassNotFoundException, IOException	{// For as long as the client wants it
		
		boolean running = true;
		boolean connected = false;
		
		System.out.println("Thread lanc�");
		
while (!connected) {
	
			String myClassName = myRequest.getClassName();
			try {
				Thread.sleep(500);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			switch(myClassName) {
			case "Request_Topic":
				myRequest.resetClassName();
				currentTopicId = myRequest.getTopic().read_topic_id();
				nbTopicMsg = -1;
				break;
				
			case "Request_Authentification":
				myRequest.resetClassName();
				int UserID = -1;
				
				//System.out.println(myRequest.getAuthentification());
				Request_Authentification myAuth = myRequest.getAuthentification();
				
				System.out.println("case \"Request_Authentification\":");
				
				 for (int i = 0; i < UserList.size(); i++)
				 {
					 System.out.println(myAuth.read_userName());
					 System.out.println(UserList.get(i).get_userName());
							 
					 if (myAuth.read_userName().equalsIgnoreCase(UserList.get(i).get_userName()))
					 {
						 UserID = i;
						 System.out.println(UserID);
						 break;
					 }
				 }
				 
				 if ((UserID >= 0) && (UserList.get(UserID).verif_password(myAuth.read_clearPassword())))	{
					 oos.writeObject(new Respond_Authentification(true, UserList.get(UserID)));
					 oos.flush();
					 connected = true;
					 System.out.println("Authentification success");
				 }else	{
					 oos.writeObject(new Respond_Authentification(false));
					 oos.flush();
					 System.out.println("Authentification fail");
				 }
				break;
				
			case "Request_Register":
				myRequest.resetClassName();
				boolean UserOk = true;
				
				System.out.println("case \"Request_Register\":");
				
				Request_Register newClient = myRequest.getRegister();
				 for (int i = 0; i < UserList.size(); i++)
				 {
					 if (newClient.read_userName().equalsIgnoreCase(UserList.get(i).get_userName()))
					 {
						 UserOk = false;
						 break;
					 }
				 }
				 
				 if (UserOk)	{
					 try {
						UserList.add(new User(newClient.read_userName(), newClient.read_clearPassword(), UserList.size()));
						oos.writeObject(new Respond_Register(true));
						oos.flush();
						System.out.println("Respond register ok");
					} catch (NoSuchAlgorithmException e) {}
				 }else	{
					 oos.writeObject(new Respond_Register(false));
					 oos.flush();
					 System.out.println("Respond register not ok");
				 }
				break;
				
			case "Request_Disconnect":
				myRequest.resetClassName();
				oos.writeObject("Au revoir !");
				oos.flush();
				
				System.out.println("Fermeture de la connexion...");
				running = false;
				connected = true;
				break;
		}
	}
	
		while (running) {
			
			try {
				Thread.sleep(500);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}			
			
			switch(myRequest.getClassName()) {
			
			case "Request_Topic":
				
				myRequest.resetClassName();
				currentTopicId = myRequest.getTopic().read_topic_id();
				System.out.println("currentTopicId = " + currentTopicId );
				oos.writeObject(TopicList.get(currentTopicId));
				oos.flush();
				System.out.println("topicName = " + TopicList.get(currentTopicId).get_topicName() );
				nbTopicMsg = TopicList.get(currentTopicId).getNumberOfMsg();
				//nbTopicMsg = 0;
				break;
				
			case "Message":
				myRequest.resetClassName();
				Message myMessage = myRequest.getMessage();
				TopicList.get(currentTopicId).addMessage(myMessage);
				break;
				
			case "Request_ListTopics":
				
				myRequest.resetClassName();
				Respond_ListTopics newList = new Respond_ListTopics(TopicList);
				oos.writeObject(newList);
				oos.flush();
				System.out.println("case \"Request_ListTopics\":");
				break;
				
			case "Request_NewTopic":
				myRequest.resetClassName();
				Request_NewTopic myNewTopic = myRequest.getNewTopic();
				Topic myTopic = new Topic(myNewTopic.read_topicName(), TopicList.size());
				currentTopicId = TopicList.size();
				TopicList.add(myTopic);
				break;
				
			case "Request_Disconnect":
				myRequest.resetClassName();
				oos.writeObject("Au revoir !");
				oos.flush();
				
				System.out.println("Fermeture de la connexion...");
				running = false;
				break;
			}
			/*
			/if (currentTopicId >= 0)
			{
				if ( nbTopicMsg != TopicList.get(currentTopicId).getNumberOfMsg() )
				{
					oos.writeObject(TopicList.get(currentTopicId));
					oos.flush();
					nbTopicMsg = TopicList.get(currentTopicId).getNumberOfMsg();
				}
			}
			*/
		}
		System.out.println("Fermeture de la connexion...");
		oos.close();
		client.close();
	}
	
	public void run() {
		System.out.println("Thread en cours de lancement");
    	try {
			this.getRequest();
		} catch (ClassNotFoundException | IOException e) {	}
    }
}

