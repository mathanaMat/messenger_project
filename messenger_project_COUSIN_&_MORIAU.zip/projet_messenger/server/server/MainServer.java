package server;

import java.io.IOException;

public class MainServer {
	
	public static void main(String[] args) {
		
		NewClient MesClients;
		
		try {
			MesClients = new NewClient();
			
			while(true)
			{
				MesClients.WaitClient();
			}
		} catch (ClassNotFoundException | IOException e) {}
	}
}
