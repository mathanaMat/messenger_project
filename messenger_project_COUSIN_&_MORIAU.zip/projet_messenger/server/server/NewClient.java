package server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import shared.Topic;
import shared.User;

public class NewClient {
	
	public static final int SERVER_PORT = 3000;
	private ServerSocket server;
	private ArrayList<Topic> TopicList = new ArrayList<Topic>();
	private ArrayList<User> UserList = new ArrayList<User>();
	
	public NewClient()	throws IOException, ClassNotFoundException {
		
		server = new ServerSocket(SERVER_PORT);
		System.out.println("Serveur chat démarrée sur le port " + SERVER_PORT);
	}
	
	public void WaitClient() throws IOException	{
		System.out.println("En attente de connexion...");
		
		/*
		 * TODO
		 * Here, you should wait for a client to connect.
		 */
		 Socket socketClient = server.accept();
		 
		 //ClientHandler unClient = new ClientHandler(socketClient, TopicList, UserList);
		 (new Thread(new ClientHandler(socketClient, TopicList, UserList))).start();
		 System.out.println("Thread lanc� in newClient");
	}
}
