package server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;

import shared.*;

public class ReadRequest implements Runnable {
	ObjectInputStream ois;
	private String className = "";
	private Request_Topic myTopic;
	private Request_Authentification myAuth;
	private Request_NewTopic myNewTopic;
	private Message myMsg;
	private Request_Register registerMe;
	
	public ReadRequest (Socket client)	 throws IOException	{
		ois = new ObjectInputStream(client.getInputStream());
	}
	
	
	public void getRequest() throws ClassNotFoundException, IOException	{// For as long as the client wants it
			
			boolean running = true;
			
			while (running) {
				
				Object monObjet;
				monObjet = ois.readObject();
				
				className = monObjet.getClass().getSimpleName();
				
				switch(className) {
				
				case "Message":
					System.out.println("Message");
					myMsg = (Message) monObjet;
					break;
					
				case "Request_Authentification":
					System.out.println("Request_Authentification");
					myAuth = (Request_Authentification) monObjet;
					//System.out.println(myAuth.read_userName());
					break;
					
				case "Request_Disconnect":
					System.out.println("Request_Disconnect");					
					System.out.println("Fermeture de la connexion...");
					running = false;
					break;
					
				case "Request_ListTopics":
					System.out.println("Request_ListTopics");
					break;
					
				case "Request_NewTopic":
					System.out.println("Request_NewTopic");
					myNewTopic = (Request_NewTopic)  monObjet;
					System.out.println("myNewTopic: " + myNewTopic.read_topicName());
					break;
					
				case "Request_Register":
					System.out.println("Request_Register");
					registerMe = (Request_Register) monObjet;
					break;
				
				case "Request_Topic":
					System.out.println("Request_Topic");
					myTopic = (Request_Topic) monObjet;
					break;
					
				}
			}
			ois.close();
		}
	
	public Request_Topic getTopic()	{
		return myTopic;
	}
	
	public Request_Authentification getAuthentification()	{
		return myAuth;
	}
	
	public String getClassName()	{
		//System.out.println(className);
		return className;
	}
	
	public void resetClassName()	{
		className = "";
	}
	
	public Message getMessage()	{
		return myMsg;
	}
	
	public Request_NewTopic getNewTopic()	{
		return myNewTopic;
	}
	
	public Request_Register getRegister()	{
		return registerMe;
	}

	@Override
	public void run() {
		try {
			this.getRequest();
		} catch (ClassNotFoundException | IOException e) {}
	}
}