package client;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
/*
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
*/
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Scanner;

import server.ReadRequest;
import shared.*;


public class Client {
	
	public static final String SERVER_HOST = null; // localhost
	public static final int SERVER_PORT = 3000;
	
	private User userConnected;
	private Topic currentTopic;
	private Respond_ListTopics listTopics;
	private Scanner sc;
	private ReadRequestClient myRequest;
	
	/**
	 * The client socket
	 */
	private Socket client;
	
	/**
	 * The client output stream
	 */
	private ObjectOutputStream outputStream;
	
	/**
	 * The client input stream
	 */
	private ObjectInputStream inputStream;
	
	
	public Client() throws UnknownHostException, IOException, NoSuchAlgorithmException, ClassNotFoundException {
		/*
		 * TODO
		 * Here you initialize the socket, the input stream, and the output stream
		 */
        try{
            client = new Socket(SERVER_HOST,SERVER_PORT);
            outputStream = new ObjectOutputStream(client.getOutputStream());
            inputStream = new ObjectInputStream(client.getInputStream());
            myRequest = new ReadRequestClient(currentTopic, inputStream);
    		(new Thread(myRequest)).start();
    		System.out.println("Thread lanc�");
        } finally {}
        
        sc = new Scanner(System.in);
        
        //startup screen:
        display_startup();
        
        sc.close();
        
	}

	
	private void display_startup() throws NoSuchAlgorithmException, IOException, ClassNotFoundException {
		
		
			
			//startup_message
			System.out.println("=#Messenger by MORIAU & COUSIN#=");
			System.out.println("\nType \"/?\" to see the list of available commands.");
		
		while(true) {
			
			//Scanner sc = new Scanner(System.in);
			
			//scan user line:
			String userTyped = sc.nextLine();
			
			//sc.close();
			
			//process user cmd:
			switch(userTyped) {
			
				case "/login":
					display_logInterface();
					break;
				
				case "/register":
					display_registerInterface();
					break;
					
				case "/?":
					display_help_startup();
					break;
				
				default:
					System.out.println("\nType \"/?\" to see the list of available commands.");
					break;
			
			}
		
		}
	}
	
	private void display_help_startup() {
		
		System.out.println("Command guide:");
		System.out.println("/login           access log interface to messenger server.");
		System.out.println("/register        register to messenger server.");
	}
	
	private void display_logInterface() throws NoSuchAlgorithmException, IOException, ClassNotFoundException {
		
		
		
		boolean authOK;
		//int attempt = 0;
		String userName;
		
		System.out.println("#LOG INTERFACE#\n");
		
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//do {
			
			//attempt++;
			
			//System.out.println("Attempt "+ attempt + "/3:\n");
			System.out.print("User name: ");
			
			//Scanner sc = new Scanner(System.in);
			
			userName = sc.nextLine();
			System.out.print("\nPassword: "); 
			//byte[] hashPassword = MessageDigest.getInstance("SHA-256").digest(sc.nextLine().getBytes(StandardCharsets.UTF_8));
			String clearPassword = sc.nextLine();
			
			//sc.close();

			outputStream.writeObject(new Request_Authentification(userName, clearPassword));
			outputStream.flush();
			
			//check server response:
			//Respond_Authentification response = (Respond_Authentification)inputStream.readObject();
			while(!myRequest.getClassName().contentEquals("Respond_Authentification"))	{}
			myRequest.resetClassName();
			Respond_Authentification response = myRequest.getAuthentification();
			authOK = response.is_auth_OK();
			
			if(!authOK) //tant que la r�ponse n'est pas auth = OK!...
				System.out.println("[Warning]No match with those IDs. Try to register.\n");
			else {
				this.userConnected = response.get_userConnected();
				display_menu_home();
			}
		//}while((attempt <= 3) & !authOK );//tant que la r�ponse n'est pas auth = OK!.
	/*	
		if (authOK) {
			//save current User object from login valid:
			this.userConnected = (User)((Respond_Authentification)inputStream.readObject()).get_userConnected();
			display_menu_home();
		}
		else {
			System.out.println("[Warning]No match with those IDs. Try to register.");
		}
		*/
		
	}
	
	private void display_registerInterface() throws NoSuchAlgorithmException, IOException, ClassNotFoundException {
		
		System.out.println("#REGISTER INTERFACE#\n");
		System.out.println("Please enter account information as requested bellow:");
		System.out.print("User name (must be unique): ");
		
		//Scanner sc = new Scanner(System.in);
		
		String userName  = sc.nextLine();
		
		//sc.close();
		
		{
			boolean usernameUnique;
			
			do{
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				String clearPassword;
				/*
				String passwordConfirm;
				do {
					System.out.print("\nPassword: ");
					
					//Scanner sc1 = new Scanner(System.in);
					
					clearPassword = sc.nextLine();
					System.out.print("\nConfirm Password: ");
					passwordConfirm = sc.nextLine();
					
					//sc.close();
					
				}while (clearPassword != passwordConfirm);
				*/
				System.out.print("\nPassword: ");
				clearPassword = sc.nextLine();
					
				System.out.println("\nPassword OK!\n");
				//byte[] hashPassword = MessageDigest.getInstance("SHA-256").digest(clearPassword.getBytes(StandardCharsets.UTF_8));
				System.out.println("Registering...\n");
				
				outputStream.writeObject(new Request_Register(userName, clearPassword));
				outputStream.flush();
				//read Respond request form server to check if username is unique (If not, user should enter another username):
				System.out.println(myRequest.getClassName());
				while(!myRequest.getClassName().equalsIgnoreCase("Respond_Register"))	{}
				System.out.println(myRequest.getClassName());
				myRequest.resetClassName();
				usernameUnique = myRequest.getRegister().username_unique();//((Respond_Register)inputStream.readObject()).username_unique();
				
				System.out.println("usernameUnique = ((Respond_Register)inputStream.readObject()).username_unique();");
				
			}while(!usernameUnique);////tant que la r�ponse n'est pas register = OK!.
		}
		
		System.out.println("You've been successfully registered!\nCome back to startup menu...");
		display_startup();
		
	}
	
	private void display_menu_home() throws NoSuchAlgorithmException, ClassNotFoundException, IOException {
		
		//startup_message
		System.out.println("#MENU#");
		System.out.println("\nType \"/?\" to see the list of available commands.");
		
		//Scanner sc = new Scanner(System.in);
		
		//scan user line:

		
		//run while user doesn't disconnect.
		boolean disconnect = false;
		while (!disconnect) {
			
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			String userTyped = sc.nextLine();
			
			//extract first word from cmd:
			String[] cmdsplited = userTyped.split(" ");
			
			//process user cmd
			switch(cmdsplited[0]) {
			
			case "/list":
				
				//display topics list
				display_list();
				break;
			
			case "/join":
				
				//join topic number in argv[1]
				int topic_id_chose = Integer.parseInt(cmdsplited[1]);
				
				//update topic list:
				outputStream.writeObject(new Request_ListTopics());
				outputStream.flush();
				//get response object from server:
				while(!myRequest.getClassName().contentEquals("Respond_ListTopics"))	{}
				myRequest.resetClassName();
				this.listTopics = myRequest.getListTopic();//(Respond_ListTopics)inputStream.readObject();
				
				boolean topicExists = false;
				//search for existing topic in the list:
				for(int i : listTopics.read_List_topic_id()) {
					if(i == topic_id_chose) {
						topicExists = true;
						break;
					}
				}
				
				if(topicExists) {
					
					//request the existing topic:
					outputStream.writeObject(new Request_Topic(topic_id_chose));
					outputStream.flush();
					//get response from server:
					while(!myRequest.getClassName().contentEquals("Topic"))	{}
					myRequest.resetClassName();;
					this.currentTopic = myRequest.getTopic();//(Topic)inputStream.readObject();
					display_menu_topic();
				}
				else
					System.out.println("[ERROR]This Topic doesn't exists!");
							
				break;
	
			case "/create":
				
				//request create
				//cmdsplited[1]
				outputStream.writeObject(new Request_NewTopic(cmdsplited[1]));
				outputStream.flush();
				break;
	
			case "/?":
				
				display_help_menu_home();
				break;
				
			case "/exit":
				
				System.out.println("\n\n=#Messenger by MORIAU & COUSIN#=");
				System.out.println("\nType \"/?\" to see the list of available commands.");
				disconnect = true;
				break;
			
			default:
				
				System.out.println("\nType \"/?\" to see the list of available commands.");
				break;
			
			}
			
		}
				
		
		
		outputStream.writeObject(new Request_Disconnect());
		outputStream.flush();
		
		//as this method ends, it will release startup menu.

	}
	
	private void display_help_menu_home() {
		
		System.out.println("Command guide:");
		System.out.println("/list					List current topics available on server.");
		System.out.println("/join <topic id>		Join a topic.");
		System.out.println("/create	<topic name>	Create a new topic.");
		System.out.println("/disconnect				Exit this menu.");
	}
	
	private void display_menu_topic() throws NoSuchAlgorithmException, ClassNotFoundException, IOException {
		
		System.out.println("#>Topic "+ this.currentTopic.get_topicName() + "<#");
		System.out.println("\nType \"/?\" to see the list of available commands.");
		
		/*
		//deprecated solution (unefficient)
		ArrayList<Message> messages = currentTopic.get_messages();
		ArrayList<String> str_messages = null;
		
		for(Message msg : messages) {
			
			str_messages.add(msg.get_messageContent());
			
		}
		*/
		
		//count number of messages to check for Topic update:
		int oldMessagesQuantity = currentTopic.get_messages().size();
		
		
		//display all messages for current topic:
		for(Message msg : currentTopic.get_messages()) {
			
			System.out.println(msg.get_author() + "> " + msg.get_messageContent());
		}
		
		boolean left = false;
		while(!left) {
			
			if(myRequest.getClassName().contentEquals("Topic")) {
						
				//update current Topic:
				currentTopic = myRequest.getTopic();
				myRequest.resetClassName();				//for checking current topic update:
				int newMessagesQuantity = currentTopic.get_messages().size();
						
				//check current topic update:
				if( newMessagesQuantity > oldMessagesQuantity) {
					
					for(int i = (oldMessagesQuantity-1); i < newMessagesQuantity; i++ ) {
						
						Message msg = currentTopic.get_messages().get(i);
						System.out.println( msg.get_author() + "> " + msg.get_messageContent() );
					}
				}
			
			
			}
			
			//scan user line:
			String userTyped = sc.nextLine();
			
			//sc.close();
			
			//process user cmd:
			switch(userTyped) {
				
				case "/?":
					
					display_help_menu_topic();
					break;
				
				case "/leave":
					
					//startup_message
					System.out.println("\n\n#MENU#");
					System.out.println("\nType \"/?\" to see the list of available commands.");
					left = true;
					break;
				
				default:
					
					outputStream.writeObject(new Message(userTyped, this.userConnected, this.currentTopic.get_topic_id()));
					outputStream.flush();
					break;
				
			}

		}

		
		/*
		//deprecated solution (unefficient)
		ArrayList<Message> messages = currentTopic.get_messages();
		ArrayList<String> str_messages = null;
		
		for(Message msg : messages) {
			
			str_messages.add(msg.get_messageContent());
			
		}
		*/
		
		/*
		//count number of messages to check for Topic update:
		int oldMessagesQuantity = currentTopic.get_messages().size();
		
		//display all messages for current topic:
		for(Message msg : currentTopic.get_messages()) {
			
			System.out.println(msg.get_author() + "> " + msg.get_messageContent());
		}
		
		boolean left = false;*/
		/*while(!left) {
			
			if(myRequest.getClassName().contentEquals("Topic")) {
						
				//update current Topic:
				currentTopic = myRequest.getTopic();
				myRequest.resetClassName();				//for checking current topic update:
				int newMessagesQuantity = currentTopic.get_messages().size();
						
				//check current topic update:
				if( newMessagesQuantity > oldMessagesQuantity) {
					
					for(int i = (oldMessagesQuantity-1); i < newMessagesQuantity; i++ ) {
						
						Message msg = currentTopic.get_messages().get(i);
						System.out.println( msg.get_author() + "> " + msg.get_messageContent() );
					}
				}
			
			//Scanner sc = new Scanner(System.in);
			
			//scan user line:
			String userTyped = sc.nextLine();
			
			//sc.close();
			
			//process user cmd:
			switch(userTyped) {
				
				case "/?":
					
					display_help_menu_topic();
					break;
				
				case "/left":
					
					//startup_message
					System.out.println("\n\n#MENU#");
					System.out.println("\nType \"/?\" to see the list of available commands.");
					left = true;
					break;
				
				default:
					
					outputStream.writeObject(new Message(userTyped, this.userConnected, this.currentTopic.get_topic_id()));
					outputStream.flush();
					break;
				
			}
			
		}
		
	}*/
	}
	
	private void display_help_menu_topic() {
		
		System.out.println("Command guide:");
		System.out.println("<message>	Send message to server on current topic.");
		System.out.println("/leave		Leave current topic.");
	}
	
	private void display_list() throws IOException, ClassNotFoundException {
		
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("List of existing topics:");
		
		//send list request to server:
		outputStream.writeObject(new Request_ListTopics());
		outputStream.flush();
		
		//get response object from server:
		/*
		Object anObject;
		boolean not_Respond_Topic = true;
		do {
			
			anObject = inputStream.readObject();
			if(anObject.getClass().getSimpleName() == "Respond_ListTopics")
				not_Respond_Topic = false;
			
		}while (not_Respond_Topic);
		
		this.listTopics = (Respond_ListTopics)anObject;
		*/
		while(!myRequest.getClassName().contentEquals("Respond_ListTopics"))	{}
		myRequest.resetClassName();
		this.listTopics = myRequest.getListTopic();//(Respond_ListTopics)inputStream.readObject();
		
		//extract available from response object:
		ArrayList<String> List_topicName = listTopics.read_List_topicName();
		ArrayList<Integer> List_topic_id = listTopics.read_List_topic_id();
		
		//print context for topics list:
		System.out.println("id\t |\t topic name");
		//print all topics id followed by their string names (from server response):
		for(int i = 0; i < List_topic_id.size(); i++) {
			
			System.out.println(List_topic_id.get(i) + "\t |\t " + List_topicName.get(i));
		}
	}


}
