package client;

//import java.io.Console;
import java.io.IOException;
import java.net.UnknownHostException;
//import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;
//import java.util.Date;
//import java.util.Scanner;

public class MainClient {

	public static void main(String[] args) throws UnknownHostException, NoSuchAlgorithmException, ClassNotFoundException, IOException {

		@SuppressWarnings("unused")
		Client ui = new Client();
		
		System.exit(0);
	}
	

}
