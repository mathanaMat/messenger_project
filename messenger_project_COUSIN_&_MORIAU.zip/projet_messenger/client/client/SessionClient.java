package client;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
//import java.util.Date;

import shared.User;

public class SessionClient {
    User user;
	Socket client;
	ObjectInputStream ois;
	ObjectOutputStream oos;
	
	SessionClient(User user){
		this.user = user;
	}
}
