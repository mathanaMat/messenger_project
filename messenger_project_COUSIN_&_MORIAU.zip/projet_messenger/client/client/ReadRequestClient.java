package client;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;

import shared.*;

public class ReadRequestClient implements Runnable {
	ObjectInputStream ois;
	private String className = "";
	private Respond_ListTopics myListTopics;
	private Respond_Authentification myAuth;
	private Respond_Register registerMe;
	private Topic currentTopic;
	
	public ReadRequestClient (Topic currentTopic, ObjectInputStream ois)	 throws IOException	{
		this.ois = ois;
		this.currentTopic = currentTopic;
	}
	
	
	public void getRequest() throws ClassNotFoundException, IOException	{// For as long as the client wants it
			
			boolean running = true;
			
			while (running) {
				
				Object monObjet;
				monObjet = ois.readObject();
				
				className = monObjet.getClass().getSimpleName();
				
				switch(className) {
					
				case "Respond_Authentification":
					System.out.println("Respond_Authentification");
					myAuth = (Respond_Authentification) monObjet;
					//System.out.println(myAuth.read_userName());
					break;
					
				case "Respond_ListTopics":
					System.out.println("Respond_ListTopics");
					myListTopics = (Respond_ListTopics) monObjet;
					break;
					
				case "Respond_Register":
					System.out.println("Respond_Register");
					registerMe = (Respond_Register) monObjet;
					break;
				
				case "Topic":
					System.out.println("Topic");
					currentTopic = (Topic) monObjet;
					break;
					
				}
			}
			ois.close();
		}
	
	public Topic getTopic()	{
		return currentTopic;
	}
	
	public Respond_Register getRegister()	{
		return registerMe;
	}
	
	public Respond_ListTopics getListTopic()	{
		return myListTopics;
	}
	
	public Respond_Authentification getAuthentification()	{
		return myAuth;
	}
	
	public String getClassName()	{
		//System.out.println(className);
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return className;
	}
	
	public void resetClassName()	{
		className = "";
	}

	@Override
	public void run() {
		try {
			this.getRequest();
		} catch (ClassNotFoundException | IOException e) {}
	}
}